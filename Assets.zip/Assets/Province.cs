﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;

public class Province
{

    public Color colorID;

    Mesh mesh;
    MeshFilter meshFilter;
    GameObject gameObject;
    public MeshRenderer meshRenderer;
    public uint maxTribeMenCapacity = 2000;
    public string name;
    public int ID;
    public Country owner;
    public List<PopUnit> allPopUnits = new List<PopUnit>();
    public Vector3 centre;

    public static List<Province> allProvinces = new List<Province>();
    private static uint defaultPopulationSpawn = 10;
    public List<Factory> allFactories = new List<Factory>();

    public Province(string iname, int iID, Color icolorID, Mesh imesh, MeshFilter imeshFilter, GameObject igameObject, MeshRenderer imeshRenderer)
    {
        colorID = icolorID; mesh = imesh; name = iname; meshFilter = imeshFilter;
        ID = iID;
        gameObject = igameObject;
        meshRenderer = imeshRenderer;
    }
    public void SecedeTo(Country taker)
    {
        //this.owner - current owner
        if (this.owner != null)
            if (this.owner.ownedProvinces != null)
                this.owner.ownedProvinces.Remove(this);
        this.owner = taker;
        if (taker.ownedProvinces == null)
            taker.ownedProvinces = new List<Province>();
        taker.ownedProvinces.Add(this);
    }
    public uint getMenPopulation()
    {
        uint result = 0;
        foreach (PopUnit pop in allPopUnits)
            result += pop.population;
        return result;
    }
    public uint getFamalyPopulation()
    {
        return getMenPopulation() * Game.familySize;
    }
    public uint getMiddleLoyalty()
    {
        //Procent result = 0;
        foreach (PopUnit pop in allPopUnits)
            ;//  result += pop.amount;
        return 0;
    }
    public static bool isProvinceCreated(Color color)
    {
        foreach (Province anyProvince in allProvinces)
            if (anyProvince.colorID == color)
                return true;
        return false;
    }
    public List<PopUnit> FindAllPopUnits(PopType ipopType)
    {
        List<PopUnit> result = new List<PopUnit>();
        foreach (PopUnit pop in allPopUnits)
            if (pop.type == ipopType)
                result.Add(pop);
        return result;
    }
    public uint FindPopulationAmountByType(PopType ipopType)
    {
        List<PopUnit> list = FindAllPopUnits(ipopType);
        uint result = 0;
        foreach (PopUnit pop in list)
            if (pop.type == ipopType)
                result += pop.population;
        return result;
    }
    internal void PayToAllAristocrats(Value fromWho, Value taxSize)
    {
        List<PopUnit> allAristocratsInProvince = FindAllPopUnits(PopType.aristocrats);
        uint aristoctrstAmount = 0;
        foreach (PopUnit pop in allAristocratsInProvince)
            aristoctrstAmount += pop.population;
        foreach (PopUnit aristocrat in allAristocratsInProvince)
        {
            //pop.storage.value.pay();
            fromWho.pay(aristocrat.storage.value, taxSize.get() * (float)aristocrat.population / (float)aristoctrstAmount);
            aristocrat.produced.value.add(taxSize.get() * aristocrat.population / aristoctrstAmount);
        }
    }
    ///<summary> Simular by popType & culture</summary>    
    public PopUnit FindSimularPopUnit(PopUnit target)
    {
        //PopUnit result = null;
        foreach (PopUnit pop in allPopUnits)
            if (pop.type == target.type && pop.culture == target.culture)
                return pop;
        return null;
    }
    public Value getMiddleNeedFullfilling(PopType type)
    {
        Value result = new Value(0);
        uint allPopulation = 0;
        List<PopUnit> localPops = FindAllPopUnits(type);
        if (localPops.Count > 0)
        {
            foreach (PopUnit pop in localPops)
            // get middle needs fullfiling according to pop weight            
            {
                allPopulation += pop.population;
                result.add(pop.NeedsFullfilled.multiple(pop.population));
            }
            return result.divide(allPopulation); ;
        }
        else/////TODO add defualt population?
        {
            PopUnit.tempPopList.Add(new PopUnit(Province.defaultPopulationSpawn, type, this.owner.culture, this));
            //return new Value(float.MaxValue);// meaning always convert in type if does not exist yet
            return new Value(0);
        }
    }

    public void BalanceEmployableWorkForce()
    {
        uint workForce = this.FindPopulationAmountByType(PopType.workers);
        
        
        if (workForce > 0)
        {
            uint wants = 0;
            List<PopUnit> popList = this.FindAllPopUnits(PopType.workers);
            popList = popList.OrderBy(o => o.population).ToList();
            allFactories = allFactories.OrderBy(o => o.getLastWorkForcePayMent()).ToList();
            foreach (Factory factory in allFactories)
            {
                wants = factory.HowMuchWorkForceWants();
                if (workForce > wants)
                {
                    workForce -= wants;
                    factory.HireWorkforce(wants, popList);
                }
                else
                {
                    factory.HireWorkforce(workForce, popList);
                    break;
                }
            }
        }
        //allFactories.
        //allFactories.Sort();

    }
}
