﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class Inventions
{
    bool invented = false;
    public void MarkInvented() { invented = true;}
    public bool Invented() { return invented; }
}
public class Country
{
    public string name;
    public static List<Country> allCountries = new List<Country>();
    public List<Province> ownedProvinces = new List<Province>();
    ///<summary> per 1000 men </summary>
    List<Needs> life = new List<Needs>();
    public Storage storage;
    public Procent countryTax;
    public Procent aristocrstTax = new Procent(0.10f);
    public Inventions farming = new Inventions(), capitalism = new Inventions();
    public Culture culture;
    public Country(string iname, Culture iculture)
    {
        name = iname;
        allCountries.Add(this);
        //default needs adding
        life.Add(new Needs(PopType.tribeMen, Product.findByName("Venison"), 1));
        life.Add(new Needs(PopType.aristocrats, Product.findByName("Venison"), 1));
        life.Add(new Needs(PopType.farmers, Product.findByName("Venison"), 1));
        storage = new Storage(Product.findByName("Venison"), 0);
        countryTax = new Procent(0.10f);

        culture = iculture;

        farming.MarkInvented();
    }

    internal uint getMenPopulation()
    {
        uint result =0;
        foreach (Province pr in ownedProvinces)
            result += pr.getMenPopulation();
        return result;
    }
    ///<summary> per 1000 men </summary>
    public Storage getLifeNeedsPer1000(PopType popType)
    {
        foreach (Needs next in life)
            if (next.popType == popType)
                return next.needs;
        return null;
    }
}
