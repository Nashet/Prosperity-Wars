﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
public class PopLinkage
{
    public PopUnit pop;
    public uint amount;
    internal PopLinkage(PopUnit p, uint a)
    {
        pop = p;
        amount = a;
    }
}
public abstract class Producer
{
    /// <summary> per 1000 men </summary>
   // public Storage basicProduction;
    public abstract void simulate();
    public abstract void produce();
    public abstract void consume();
    public abstract void payTaxes();



    public Storage storage;
    public Storage produced;

    public Country owner; //TODO Could be any Country or POP
    public Province province;
}
public abstract class Factory : Producer
{
    public enum Types { Forestry, GoldMine, MetalMine };
    public Types type;
    protected uint workForcePerLevel = 1000;
    protected byte level = 1;
    ///<summary> per 1000 men </summary>
    public static Storage basicProduction;
    /// <summary> income list </summary>
    private static StorageSet resource = new StorageSet();
    protected List<PopLinkage> workForce = new List<PopLinkage>();
    
    protected Factory(Province iprovince)
    {
        iprovince.allFactories.Add(this);
        owner = iprovince.owner;
        province = iprovince;
    }
    public override void simulate()
    {
        //hireWorkForce();
        produce();
        payTaxes();
        paySalary();
        consume();

    }
    public uint getWorkForce()
    {
        uint result = 0;
        foreach (PopLinkage pop in workForce)
            result += pop.amount;
        return result;
    }
    public void HireWorkforce(uint amount, List<PopUnit> popList)
    {
        workForce.Clear();
        uint leftToHire = amount;
        // Do check on no too much workers?
        foreach (PopUnit pop in popList)
        {
            if (pop.population >= leftToHire) // satisfied demand
            {
                workForce.Add(new PopLinkage(pop, leftToHire));
                break;
            }
            else
            {
                workForce.Add(new PopLinkage(pop, pop.population)); // hire as we can
                leftToHire -= pop.population;
            }
        }
    }
    

    private void paySalary()
    {
        // per 1000 men
        Value salary = new Value(1);
        if (owner.capitalism.Invented())
            ;
        else
        {
            foreach (PopLinkage link in workForce)
            {
                Value howMuchPay = new Value(0);
                howMuchPay.set(salary.get() *link.amount / 1000);
                owner.storage.value.pay(link.pop.storage.value, howMuchPay);
            }
        }
    }
    public override void produce()
    {
        Value producedAmount;

        producedAmount = new Value(getWorkForce() * basicProduction.value.get() / 1000f);
        storage.value.add(producedAmount);
        produced.set(producedAmount);

        if (owner.capitalism.Invented())
            ;// Try to sell
        else // send all production to owner
            storage.value.sendAll(owner.storage.value);
    }
    /// <summary> only make sense if called before HireWorkforce()
    ///  PEr 100 men!!!
    /// !!! Mirroring PaySalary
    /// </summary>    
    public float getLastWorkForcePayMent()
    {
        // per 1000 men
        Value salary = new Value(1);
        //if (owner.capitalism.Invented())
        //    ;
        //else
        //{
        //    foreach (PopLinkage link in workForce)
        //    {
        //        Value howMuchPay = new Value(0);
        //        howMuchPay.set(salary.get() * link.amount / 1000);
        //        owner.storage.value.pay(link.pop.storage.value, howMuchPay);
        //    }
        //}

        return salary.get();
    }
    public uint MaxWorkforceCapacity()
    {
        uint cantakeMax = level * workForcePerLevel;
        return cantakeMax;
    }
    public uint HowMuchWorkForceWants()
    {
        return MaxWorkforceCapacity();
    }
    public override void payTaxes() // currently no taxes for factories
    {

    }
}
public class GoldMine : Factory
{
    public static string name = "Gold mine";
    public GoldMine(Province iprovince) : base(iprovince)
    {
        basicProduction = new Storage(Product.findByName("Gold"), 3f);
        produced = new Storage(Product.findByName("Gold"));
        type = Types.GoldMine;
    }

    public override void consume()
    {

    }  

}
public class Forestry : Factory
{
    public static string name = "Forestry";
    public Forestry(Province province) : base(province)
    {
        basicProduction = new Storage(Product.findByName("Wood"), 2f);
        produced = new Storage(Product.findByName("Wood"));
        type = Types.Forestry;
    }

    public override void consume()
    {

    }

}
