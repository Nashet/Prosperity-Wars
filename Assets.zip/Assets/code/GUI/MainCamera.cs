﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainCamera : MonoBehaviour
{
    public Game game;
    Camera cameraMy;
    GameObject mapPointer;
    public static TopPanel topPanel;
    public static ProvincePanel provincePanel;
    public static PopulationPanel populationPanel;
    public static PopUnitPanel popUnitPanel;
    // Use this for initialization
    //public Text generalText;
    void Start()
    {
        game = new Game();
        GameObject gameControllerObject = GameObject.FindWithTag("MainCamera");
        if (gameControllerObject != null)
        {
            cameraMy = gameControllerObject.GetComponent<Camera>();
        }
        if (cameraMy == null)
        {
            Debug.Log("Cannot find 'cameraMy' ");
        }
        mapPointer = GameObject.FindWithTag("pointerMy");
        if (mapPointer == null)
        {
            Debug.Log("Cannot find 'pointerMy' ");
        }
        //topPanel = transform.FindChild("TopPanel").gameObject;
        //.GetComponent<Panel>()
    }
    int GetRayCastMeshNumber()
    {

        RaycastHit hit;
        if (!Physics.Raycast(cameraMy.ScreenPointToRay(Input.mousePosition), out hit))
            return -1;

        MeshCollider meshCollider = hit.collider as MeshCollider;

        if (meshCollider == null || meshCollider.sharedMesh == null)
            return -2;
        Mesh mesh = meshCollider.sharedMesh;

        //Vector3[] vertices = mesh.vertices;
        //int[] triangles = mesh.triangles;

        //Vector3 p0 = vertices[triangles[hit.triangleIndex * 3 + 0]];

        //mapPointer.transform.position = p0;
        //// Gets a vector that points from the player's position to the target's.
        //Vector3 heading = mapPointer.transform.position - Vector3.zero;
        //heading.Normalize();

        // mapPointer.transform.position += heading * 50;
        // mapPointer.transform.rotation = Quaternion.LookRotation(heading, Vector3.up) * Quaternion.Euler(-90, 0, 0);

        //return groundMesh.triangles[hit.triangleIndex * 3];
        ;
        return System.Convert.ToInt32(mesh.name);
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // clicked and released left button
        {
            int meshNumber = GetRayCastMeshNumber();
            if (Game.selectedProvince != null && meshNumber >=0)
                Game.selectedProvince.meshRenderer.material.color = Game.selectedProvince.colorID;
            
            if (meshNumber >= 0) //found something correct
            {
                Province.allProvinces[meshNumber].meshRenderer.material.color = Color.gray;
                Game.selectedProvince = Province.allProvinces[GetRayCastMeshNumber()];
                provincePanel.Show();
            }

        }

        if (Game.haveToStepSimulation)
        {
            Game.stepSimulation();
            Game.haveToStepSimulation = false;
            topPanel.Refresh();
            popUnitPanel.Refresh();
            populationPanel.Refresh();
        }
        else if (Game.haveToRunSimulation)
        {
            Game.stepSimulation();
            topPanel.Refresh();
            popUnitPanel.Refresh();
            populationPanel.Refresh();
        }
        if (Game.selectedProvince != null)
            ProvincePanel.UpdateProvinceWindow(Game.selectedProvince);
        
    }
    // This function is called every fixed framerate frame, if the MonoBehaviour is enabled.
    void FixedUpdate()
    {
        float xyCameraSpeed = 10f;
        float zCameraSpeed = 250f;
        float xMove = Input.GetAxis("Horizontal");
        float yMove = Input.GetAxis("Vertical");
        float zMove = Input.GetAxis("Mouse ScrollWheel");
        transform.Translate(xMove * xyCameraSpeed, yMove * xyCameraSpeed, zMove * zCameraSpeed);
    }

}
