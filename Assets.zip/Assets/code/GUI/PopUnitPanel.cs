﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class PopUnitPanel : MonoBehaviour
{
    public  GameObject popUnitPanel;
    public Text generaltext;
    private PopUnit pop;
    // Use this for initialization
    void Start()
    {
        MainCamera.popUnitPanel = this;
        Hide();
    }

    // Update is called once per frame
    void Update()
    {
        //Refresh();
    }
    public void Refresh()
    {
        if (pop != null)
        {
            string demotionText;
            if (pop.WantsDemotion())
                demotionText = pop.getRichestDemotionTarget().name + " " + pop.getDemotionSize();
            else demotionText = "none";
            generaltext.text = pop.type.name + "\n" + "Population: " + pop.population + "\nOwns: " + pop.storage.ToString()
                + "\n Income: " + pop.produced.ToString() + "\nExpenses:"
                + "\nDemotion: " + demotionText +"\nGrowth: " + pop.getGrowthSize();
        }
    }
    public  void Show(PopUnit ipopUnit)
    {
        popUnitPanel.SetActive(true);
        pop = ipopUnit;
    }
    public void Hide()
    {
        popUnitPanel.SetActive(false);
    }
    public void onCloseClick()
    {
        Hide();
    }
}