﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
public class PopulationPanel : MonoBehaviour {
    public GameObject populationPanel;
   // public GameObject ScrollViewMy;
    public ScrollRect table;
    // Use this for initialization
    void Start () {
        MainCamera.populationPanel = this;
        Hide();
        
    }
    public void Hide()
    {
        populationPanel.SetActive(false);
    }
   
    public void Show()
    {

        populationPanel.SetActive(true);
        
        
    }
    public void onCloseClick()
    {
        Hide();
    }
    public void onShowAllClick()
    {
        Hide();
        List<PopUnit> er = new List<PopUnit>();
        Game.popListToShow.Clear();
        foreach (Province province in Game.player.ownedProvinces)
            foreach (PopUnit popUnit in province.allPopUnits)
                // Game.popListToShow.Add(popUnit);
                er.Add(popUnit);
        Game.popListToShow = er;
        Show();
            
    }
    public void Refresh()
    {
        Hide();
        Show();
    }
    // Update is called once per frame
    void Update () {
	
	}
}
