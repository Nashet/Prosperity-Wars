﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public   class ProvincePanel : MonoBehaviour
{
    public static Text generaltext;
    public GameObject provincePanel;
    // Use this for initialization
    // thisPanel;
    void Start()
    {
       // thisPanel = GameObject.Find("ProvincePanel");
        //generaltext = Panel.Find("Generaltext").GetComponent<Text>();
      //  generaltext = GameObject.Find("ProvincePanel/Generaltext").GetComponent<Text>();
      //  generaltext = gameObject.GetComponentInChildren<Text>();
        generaltext = transform.FindChild("GeneralText").gameObject.GetComponent<Text>();
        //generaltext = this.Find("Generaltext").GetComponent<Text>();
        //generaltext = GetComponent<Text>();
        MainCamera.provincePanel = this;
        Hide();
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void Hide() {
        provincePanel.SetActive(false);
    }
    public void Show()
    {
        provincePanel.SetActive(true);
    }
    public void onCloseClick()
    {
        Hide();
    }
    public void onPopulationDetailsClick()
    {
        Game.popListToShow = Game.selectedProvince.allPopUnits;
        MainCamera.populationPanel.Show();
    }
    public static void UpdateProvinceWindow(Province province)
    {
        generaltext.text = "name: " + province.name + "\nID: " + province.ID +"\nPopulation (+/-): "+ province.getFamalyPopulation()
            + "\nMiddle loyalty" + "\nTax income"; 
    }
}
