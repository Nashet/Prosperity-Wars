﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using System;

// represen each opunit record in table
public class Record
{

    public PopUnit popUnit;


    public Record(PopUnit ipopunit)
    {
        popUnit = ipopunit;
        //    name = popUnit.popType.name;

    }
    //public Sprite icon;
    //public float price = 1;

}

public class ShopScrollList : MonoBehaviour
{

    //public List<Record> recordList;
    public Transform contentPanel; // myself
    //public GameObject parentPanel;
    //public ShopScrollList otherShop;
    private int rowHeight = 20;
    public int columnsAmount;

    public SimpleObjectPool buttonObjectPool;


    // Use this for initialization
    void Start()
    {

    }
    void OnEnable()
    {
        Refresh();
    }
    void Refresh()
    {
        RemoveButtons();
        AddButtons();
        contentPanel.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, contentPanel.childCount / this.columnsAmount * rowHeight + 50);
    }
    void Update()
    {
       // Refresh();
    }
    private void RemoveButtons()
    {
        int count = contentPanel.childCount;
        for (int i = 0; i < count; i++)
        {
            GameObject toRemove = contentPanel.GetChild(0).gameObject;
            buttonObjectPool.ReturnObject(toRemove);
        }
    }

    private void AddButtons()
    {
        int counter = 0;
        if (Game.popListToShow != null)
            foreach (PopUnit record in Game.popListToShow)
            {

                //GameObject newButton = buttonObjectPool.GetObject();
                //newButton.transform.SetParent(contentPanel);
                //SampleButton sampleButton = newButton.GetComponent<SampleButton>();
                //sampleButton.Setup(record.popType.name, record, this);


                //newButton = buttonObjectPool.GetObject();
                //newButton.transform.SetParent(contentPanel);
                //sampleButton = newButton.GetComponent<SampleButton>();
                //sampleButton.Setup(System.Convert.ToString(record.population), record, this);
                // Adding nomber
                AddButton(Convert.ToString(counter), record);
                // Adding PopType
                AddButton(record.type.name, record);
                ////Adding population
                AddButton(System.Convert.ToString(record.population), record);
                ////Adding culture
                AddButton(record.culture.name, record);
                ////Adding province
                AddButton(record.province.name, record);
                ////Adding education
                AddButton(record.education.ToString(), record);
                ////Adding storage
                if (record.storage != null)
                    AddButton(record.storage.value.ToString(), record);
                else AddButton("Administration", record);                
                ////Adding needs fulfilling
                AddButton(record.NeedsFullfilled.ToString(), record);
                ////Adding loyalty
                AddButton(record.loyalty.ToString(), record);
                counter++;
                //contentPanel.r
            }
        //}
    }
    private void AddButton(string text, PopUnit record)
    {
        GameObject newButton = buttonObjectPool.GetObject();
        newButton.transform.SetParent(contentPanel);
        SampleButton sampleButton = newButton.GetComponent<SampleButton>();
        sampleButton.Setup(text, record, this);
    }
    //public void TryTransferItemToOtherShop(Item item)
    //{
    //    if (otherShop.gold >= item.price)
    //    {
    //        gold += item.price;
    //        otherShop.gold -= item.price;

    //        AddItem(item, otherShop);
    //        RemoveItem(item, this);

    //        RefreshDisplay();
    //        otherShop.RefreshDisplay();
    //        Debug.Log("enough gold");

    //    }
    //    Debug.Log("attempted");
    //}

    //void AddItem(Record itemToAdd, ShopScrollList shopList)
    //{
    //    shopList.recordList.Add(itemToAdd);
    //}

    //private void RemoveItem(Record itemToRemove, ShopScrollList shopList)
    //{
    //    for (int i = shopList.recordList.Count - 1; i >= 0; i--)
    //    {
    //        if (shopList.recordList[i] == itemToRemove)
    //        {
    //            shopList.recordList.RemoveAt(i);
    //        }
    //    }
    //}
}