﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public  class TopPanel : MonoBehaviour {
    public Button btnPlay, btnStep;
    public  Text generalText;
    // Use this for initialization
    void Start () {
        //generaltext = transform.FindChild("GeneralText").gameObject.GetComponent<Text>();
        btnPlay.onClick.AddListener(() => onbtnPlayClick(btnPlay));
        btnStep.onClick.AddListener(() => onbtnStepClick(btnPlay));
        btnPlay.image.color = Color.grey;
        MainCamera.topPanel = this;
    }
	
	// Update is called once per frame
	void Update () {
	
	}
    public  void Refresh()
    {
        generalText.text = "Date: " +  Game.date + " Country: " + Game.player.name + " Storage: " + Game.player.storage.value.get()
            +" Population: " + Game.player.getMenPopulation() ;
    }
    void onbtnStepClick(Button button)
    {
        Game.haveToStepSimulation = true;
    }
    void onbtnPlayClick(Button button)
    {
        Game.haveToRunSimulation = !Game.haveToRunSimulation;
        if (Game.haveToRunSimulation)
        {
            button.image.color = Color.white;
            Text text = button.GetComponentInChildren<Text>();
            text.text = "Playing";
        }
        else
        {
            button.image.color = Color.grey;
            Text text = button.GetComponentInChildren<Text>();
            text.text = "Pause";
        }
    }
}
