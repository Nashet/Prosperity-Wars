﻿using UnityEngine;
using B83.Image.BMP;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.IO;
using System;

public class Game
{
    Texture2D mapImage;
    GameObject mapObject;
    //Mesh mapMesh;
    List<int> trianglesList = new List<int>();
    List<Vector3> verti = new List<Vector3>();
    int triangleCounter = 0;
    public static Country player;
    internal static bool haveToRunSimulation;
    internal static bool haveToStepSimulation;
    public static System.Random random = new System.Random();

    public static Province selectedProvince;
    public static List<PopUnit> popListToShow;


    internal static uint familySize = 5;

    public static uint date;
    float cellMuliplier = 2f;
    public Game()
    {

        LoadImages();
        MakeMap();
        FindProvinceCenters();
        new Product("Venison");
        new Product("Wood");
        new Product("Gold");
        new Product("Metall");

        //new Product("Grain");

        new PopType(PopType.Types.TribeMen, new Storage(Product.findByName("Venison"), 1.5f), "Tribemen");
        new PopType(PopType.Types.Aristocrats, null, "Aristocrats");
        new PopType(PopType.Types.Farmers, new Storage(Product.findByName("Venison"), 3f), "Farmers");
        new PopType(PopType.Types.Artisans, null, "Artisans");
        new PopType(PopType.Types.Soldiers, null, "Soldiers");
        new PopType(PopType.Types.Soldiers, null, "Workers");

        player = new Country("Kocopia", new Culture("Kocopetji"));

        CreateRandomPopulation();
        new GoldMine(Province.allProvinces[0]);
        new Forestry(Province.allProvinces[0]);
        MainCamera.topPanel.Refresh();
    }
    void CreateRandomPopulation()
    {
        uint chanceForA = 85;

        foreach (Province province in Province.allProvinces)
        {
            province.SecedeTo(player);
            Culture culture = new Culture(province.name + "landers");


            province.allPopUnits.Add(
                new PopUnit(PopUnit.getRandomPopulationAmount(), PopType.tribeMen, culture, province)
                );

            //if (Procent.GetChance(chanceForA))
            //    province.allPopUnits.Add(
            //    new PopUnit(PopUnit.getRandomPopulationAmount(), PopType.aristocrats, culture, province)
            //    );

        }


    }
    void makeTriangle(float x, float y, float x2, float y2)
    {

        verti.Add(new Vector3(x, y, 0));
        verti.Add(new Vector3(x2, y, 0));
        verti.Add(new Vector3(x2, y2, 0));
        verti.Add(new Vector3(x, y2, 0));

        trianglesList.Add(0 + triangleCounter);
        trianglesList.Add(1 + triangleCounter);
        trianglesList.Add(2 + triangleCounter);

        trianglesList.Add(2 + triangleCounter);
        trianglesList.Add(3 + triangleCounter);
        trianglesList.Add(0 + triangleCounter);
        triangleCounter += 4;
    }
    void MakeMap()
    {


        mapObject = GameObject.Find("MapObject");
        mapImage = UtilsMy.FlipTexture(mapImage); ;

        Color currentProvinceColor = mapImage.GetPixel(0, 0);
        Color currentColor, lastColor, lastprovinceColor = mapImage.GetPixel(0, 0); //, stripeColor;
        int provinceCounter = 0;
        for (int j = 0; j < mapImage.height; j++) // cicle by province        
            for (int i = 0; i < mapImage.width; i++)
            {
                // nextColor = mapImage.GetPixel(i, j);
                currentProvinceColor = mapImage.GetPixel(i, j);
                //if (nextColor == currentProvinceColor)
                if ((lastprovinceColor != currentProvinceColor) && !Province.isProvinceCreated(currentProvinceColor))
                { // fill up province's mesh
                    // making mesh by BMP        
                    int stripeLenght = 0;
                    lastColor = mapImage.GetPixel(0, 0);
                    //stripeColor = lastColor;
                    for (int ypos = 0; ypos < mapImage.height; ypos++)
                    {
                        for (int xpos = 0; xpos < mapImage.width; xpos++)
                        {

                            currentColor = mapImage.GetPixel(xpos, ypos);
                            if (currentColor == currentProvinceColor)
                            {
                                stripeLenght++;

                            }
                            else //place for trangle making
                            {
                                if (lastColor == currentProvinceColor)
                                {
                                    makeTriangle((xpos - stripeLenght) * cellMuliplier, ypos * cellMuliplier, xpos * cellMuliplier, (ypos + 1) * cellMuliplier); //should form 2 triangles
                                    stripeLenght = 0;
                                }
                            }
                            lastColor = currentColor;
                        }
                        if (stripeLenght != 0)
                            if (lastColor == currentProvinceColor)
                            {
                                makeTriangle((mapImage.width - 1 - stripeLenght) * cellMuliplier, ypos * cellMuliplier, (mapImage.width - 1) * cellMuliplier, (ypos + 1) * cellMuliplier); //should form 2 triangles
                                stripeLenght = 0;
                            }
                        stripeLenght = 0;
                    }
                    //finished all map search for currentProvince

                    //spawn object
                    GameObject objToSpawn = new GameObject(string.Format("{0}", provinceCounter));

                    //Add Components
                    MeshFilter meshFilter = objToSpawn.AddComponent<MeshFilter>();
                    MeshRenderer meshRenderer = objToSpawn.AddComponent<MeshRenderer>();

                    // in case you want the new gameobject to be a child
                    // of the gameobject that your script is attached to
                    objToSpawn.transform.parent = mapObject.transform;

                    Mesh mesh = meshFilter.mesh;
                    mesh.Clear();

                    mesh.vertices = verti.ToArray(); //map.getGroundVertices3();
                    mesh.triangles = trianglesList.ToArray();
                    mesh.RecalculateNormals();
                    mesh.RecalculateBounds();

                    //Renderer rend = GetComponent<Renderer>();
                    meshRenderer.material.shader = Shader.Find("Standard");
                    //meshRenderer.material.SetColor("_SpecColor", currentProvinceColor);
                    meshRenderer.material.color = currentProvinceColor;

                    MeshCollider groundMeshCollider;
                    groundMeshCollider = objToSpawn.AddComponent(typeof(MeshCollider)) as MeshCollider;
                    groundMeshCollider.sharedMesh = mesh;

                    verti.Clear();
                    trianglesList.Clear();
                    triangleCounter = 0;

                    //Vector2[] del = new Vector2[1];

                    //del[0].x = provinceCounter;
                    mesh.name = provinceCounter.ToString();
                    //provinceCounter;
                    Province newProvince = new Province(string.Format("{0}", provinceCounter),
                        provinceCounter, currentProvinceColor, mesh, meshFilter, objToSpawn, meshRenderer);
                    Province.allProvinces.Add(newProvince);


                    newProvince.centre = meshRenderer.bounds.center;
                   // newProvince.centre = objToSpawn.rigidbody.centerOfMass

                    var    variableForPrefab = (GameObject)Resources.Load("prefabs/3dTextPrefab", typeof(GameObject));
                    Transform txtMeshTransform = GameObject.Instantiate(variableForPrefab).transform;
                    txtMeshTransform.SetParent(objToSpawn.transform);

                    txtMeshTransform.position = newProvince.centre;

                    TextMesh txtMesh = txtMeshTransform.GetComponent<TextMesh>();
                    txtMesh.text = newProvince.name;
                    txtMesh.color = Color.red; // Set the text's color to red

                    //TextMesh newText = TextMesh();
                    // gameObject.rigidbody.centerOfMass

                    provinceCounter++;


                }
                else
                {
                    // currentProvinceColor = nextColor;
                }
                lastprovinceColor = currentProvinceColor;
            }
    }

    internal static void stepSimulation()
    {
        date++;
        PopUnit.SetZeroIncome();
        foreach (Country country in Country.allCountries)
            foreach (Province province in country.ownedProvinces)//Province.allProvinces)
            {
                //Now factories time!
                province.BalanceEmployableWorkForce();
                foreach (Factory fact in province.allFactories)
                    fact.simulate();
                foreach (PopUnit pop in province.allPopUnits)
                // pop.simulate(province);
                //producing simulation
                {
                    if (pop.type.basicProduction != null)
                    {
                        pop.produce();

                    }
                    if (pop.type != PopType.aristocrats)
                    {
                        pop.payTaxes();
                        pop.PayToAllAristocrats();
                    }
                    pop.consume();
                    pop.calcLoyalty();
                    pop.calcPromotions();
                    pop.calcDemotions();
                    pop.calcGrowth();
                }
                //province.allPopUnits.Add(PopUnit.tempPopList);
                foreach (PopUnit pop in PopUnit.tempPopList)
                {
                    PopUnit targetToMerge = province.FindSimularPopUnit(pop);
                    if (targetToMerge == null)
                        province.allPopUnits.Add(pop);
                    else
                        targetToMerge.Merge(pop);
                }
                PopUnit.tempPopList.Clear();
                
            }

    }
    bool FindProvinceCenters()
    {
        short[,] bordersMarkers = new short[mapImage.width, mapImage.height];

        int foundedProvinces = 0;
        Color currentColor;
        short borderDeepLevel = -1;
        short alphaChangeForLevel = 1;
        float defaultApha = 1f;
        int placedMarkers = int.MaxValue;
        //while (Province.allProvinces.Count != foundedProvinces)
        foreach (Province pro in Province.allProvinces)
        {
            borderDeepLevel = 0;
            placedMarkers = int.MaxValue;
            while (placedMarkers != 0)
            {
                placedMarkers = 0;
                borderDeepLevel += alphaChangeForLevel;
                for (int j = 0; j < mapImage.height; j++) // cicle by province        
                    for (int i = 0; i < mapImage.width; i++)
                    {

                        currentColor = mapImage.GetPixel(i, j);
                        //if (UtilsMy.isSameColorsWithoutAlpha(currentColor, pro.colorID) && currentColor.a == defaultApha && isThereOtherColorsIn4Negbors(i, j))
                        if (currentColor == pro.colorID && bordersMarkers[i, j] == 0 && isThereOtherColorsIn4Negbors(i, j, bordersMarkers, (short)(borderDeepLevel - 1)))
                        {
                            //currentColor.a = borderDeepLevel;
                            //mapImage.SetPixel(i, j, currentColor);
                            bordersMarkers[i, j] = borderDeepLevel;
                            placedMarkers++;

                        }
                    }

                //if (placedMarkers == 0) 
                //    ;
            }
            //// found centers!
            bool wroteResult = false;
            for (int j = 0; j < mapImage.height && !wroteResult; j++) // cicle by province, looking where is my centre        
                for (int i = 0; i < mapImage.width && !wroteResult; i++)
                {
                    currentColor = mapImage.GetPixel(i, j);
                    //if (currentColor.a == borderDeepLevel)
                    if (currentColor == pro.colorID && bordersMarkers[i, j] == borderDeepLevel - 1)
                    {
                        pro.centre = new Vector3((i + 0.5f) * cellMuliplier, (j + 0.5f) * cellMuliplier, 0f);
                        wroteResult = true;
                    }
                }
        }
        return false;
    }
    bool isThereOtherColorsIn4Negbors(int x, int y, short[,] bordersMarkers, short borderDeepLevel)
    {
        Color color = mapImage.GetPixel(x, y);
        //if (x == 0)
        //    return true;
        //else
        //    if (!UtilsMy.isSameColorsWithoutAlpha(mapImage.GetPixel(x - 1, y), color)) return true;

        //if (x == mapImage.width - 1)
        //    return true;
        //else
        //    if (!UtilsMy.isSameColorsWithoutAlpha(mapImage.GetPixel(x + 1, y), color)) return true;
        //if (y == 0)
        //    return true;
        //else
        //    if (!UtilsMy.isSameColorsWithoutAlpha(mapImage.GetPixel(x, y - 1), color)) return true;
        //if (y == mapImage.height - 1)
        //    return true;
        //if (!UtilsMy.isSameColorsWithoutAlpha(mapImage.GetPixel(x, y + 1), color)) return true;
        //return false;
        if (x == 0)
            return true;
        else
          if (mapImage.GetPixel(x - 1, y) != color || bordersMarkers[x - 1, y] != borderDeepLevel) return true;

        if (x == mapImage.width - 1)
            return true;
        else
            if (mapImage.GetPixel(x + 1, y) != color || bordersMarkers[x + 1, y] != borderDeepLevel) return true;
        if (y == 0)
            return true;
        else
            if (mapImage.GetPixel(x, y - 1) != color || bordersMarkers[x, y - 1] != borderDeepLevel) return true;
        if (y == mapImage.height - 1)
            return true;
        if (mapImage.GetPixel(x, y + 1) != color || bordersMarkers[x, y + 1] != borderDeepLevel) return true;
        return false;
    }
    void LoadImages()
    {
        ////Loadin images...
        //BMPLoader loader = new BMPLoader();
        ////loader.ForceAlphaReadWhenPossible = true; // can be uncomment to read alpha

        ////load the image data
        //BMPImage img = loader.LoadBMP("assets\\provinces.bmp");

        //// Convert the Color32 array into a Texture2D
        //mapImage = img.ToTexture2D();
        //mapImage = (Texture2D)Resources.Load("assets\\provinces");
        byte[] bytes = File.ReadAllBytes("assets\\provinces.png");
        Texture2D texture = new Texture2D(2, 2);
        texture.filterMode = FilterMode.Trilinear;
        texture.LoadImage(bytes);
        mapImage = texture;

        RawImage ri = GameObject.Find("RawImage").GetComponent<RawImage>();
        //Image ri = GameObject.Find("Image").GetComponent<Image>();
        ri.texture = mapImage;


    }

}
