﻿using UnityEngine;
using System.Collections;

public class Needs
{
    //Product product;
    public PopType popType;
    //*For 1000 population*//
    //public Value needs;
    public Storage needs;
    public Needs(PopType ipopType, Product iproduct, uint iamount)
    {
        //product = iproduct;
        popType = ipopType;
        needs = new Storage(iproduct, iamount);
    }
}
