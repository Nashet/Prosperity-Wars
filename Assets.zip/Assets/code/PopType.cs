﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class PopType  {

    //string name;
    public enum Types { TribeMen, Aristocrats, Farmers, Artisans, Soldiers, Workers };
    public static PopType tribeMen, aristocrats, farmers, artisans, soldiers, workers;
    public Types type;
    public static List<PopType> allPopTypes = new List<PopType>();
    ///<summary> per 1000 men </summary>
    public Storage basicProduction;
    public string name;
    public PopType(Types itype, Storage iproduces, string iname)
    {
        type = itype;
        name = iname;
        basicProduction = iproduces;
        allPopTypes.Add(this);
        switch (itype){
            case Types.TribeMen:
                tribeMen = this;
                break;
            case Types.Aristocrats:
                aristocrats = this;
                break;
            case Types.Farmers:
                farmers = this;
                break;
            case Types.Artisans:
                artisans = this;
                break;
            case Types.Soldiers:
                soldiers = this;
                break;
            case Types.Workers:
                workers = this;
                break;
            default:
                Debug.Log("Unnown PopType");
                break;
        }

    }

    
}
