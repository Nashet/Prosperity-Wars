﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class PopUnit :Producer
{
    public static Procent growthSpeed = new Procent(0.01f);
    public static Procent starvationSpeed = new Procent(0.01f);

    ///<summary> demotion  - when popUnit can't fullfill needs</summary>
    public static Procent demotionSpeed = new Procent(0.01f);

    ///<summary> promotion  - when popUnit has chance to get better place in ierarhy</summary>
    public static Procent promotionSpeed = new Procent(0.01f);

    ///<summary>buffer popList of demoter. To avoid iteration breaks</summary>
    public static List<PopUnit> tempPopList = new List<PopUnit>();

    public Procent loyalty;
    public uint population;
    public PopType type;
    public Culture culture;
    public Procent education;
    public Procent NeedsFullfilled;
    //, everyDayNeeds, luxuryNeeds;
    //public Storage storage;
    //public Storage produced;

    //public Country owner;
    //public Province province;

    public static int minGeneratedPopulation = 100;
    public static int maxGeneratedPopulation = 2500;
    public static uint getRandomPopulationAmount()
    {
        uint randomPopulation = (uint)(minGeneratedPopulation + Game.random.Next(maxGeneratedPopulation - minGeneratedPopulation));
        return randomPopulation;
    }
    public PopUnit(uint iamount, PopType ipopType, Culture iculture, Province where)
    {
        population = iamount;
        type = ipopType;
        culture = iculture;

        //where.allPopUnits.Add(this);

        // if (ipopType.basicProduction != null)
        //     storage = new Storage(ipopType.basicProduction.getProduct(), 0);
        storage = new Storage(Product.findByName("Venison"), 0);
        produced = new Storage(Product.findByName("Venison"), 0);
        education = new Procent(0.01f);
        loyalty = new Procent(0.50f);
        NeedsFullfilled = new Procent(1f);

        owner = where.owner;
        province = where;
    }
    public PopUnit(PopUnit ipopUnit)
    {
        population = ipopUnit.population;
        type = ipopUnit.type;
        culture = ipopUnit.culture;

        // if (ipopType.basicProduction != null)
        //     storage = new Storage(ipopType.basicProduction.getProduct(), 0);
        storage = new Storage(Product.findByName("Venison"), 0);
        produced = new Storage(Product.findByName("Venison"), 0);
        education = new Procent(ipopUnit.education.get());

        loyalty = new Procent(ipopUnit.loyalty.get());
        NeedsFullfilled = new Procent(ipopUnit.NeedsFullfilled.get());

        owner = ipopUnit.owner;
        province = ipopUnit.province;
        //province.allPopUnits.Add(this);

        tempPopList.Add(this);
    }

    public override void produce()
    {
        float tribeMenOverPopulationFactor = 1f; //goes to zero with 20

        switch (type.type)
        {
            case PopType.Types.TribeMen:
                Value producedAmount;
                if (population <= province.maxTribeMenCapacity)
                    producedAmount = new Value(population * type.basicProduction.value.get() / 1000f);
                else
                {
                    uint overPopulation = province.getMenPopulation() - province.maxTribeMenCapacity;
                    float over = (float)(overPopulation / (float)province.maxTribeMenCapacity);
                    producedAmount = new Value(population * type.basicProduction.value.get() / 1000f); //TODO fix shit

                    Value negation = new Value(producedAmount.get() * over / tribeMenOverPopulationFactor);
                    if (negation.get() > producedAmount.get()) producedAmount.set(0);
                    else
                        producedAmount.subtract(negation);

                }
                storage.value.add(producedAmount);
                produced.set(producedAmount);

                break;
            case PopType.Types.Aristocrats:

                break;
            case PopType.Types.Farmers:
                producedAmount = new Value(population * type.basicProduction.value.get() / 1000);
                storage.value.add(producedAmount);
                produced.set(producedAmount);
                break;
            case PopType.Types.Artisans:

                break;
            case PopType.Types.Soldiers:

                break;
            default:
                Debug.Log("Unnown PopType in Game.cs");
                break;

        }
    }
    public override void payTaxes()
    {
        Value taxSize = new Value(0);
        taxSize = produced.value.multiple(owner.countryTax);
        storage.value.pay(owner.storage.value, taxSize);
    }
    public override void consume()
    {
        float lifeNeeds = Game.player.getLifeNeedsPer1000(this.type).value.get() * this.population / 1000;
        if (storage.value.get() >= lifeNeeds)
        {
            storage.value.subtract(lifeNeeds);
            NeedsFullfilled.set(1);
        }
        else
        {
            float canConsume = storage.value.get();
            storage.value.set(0);
            NeedsFullfilled.set(canConsume / lifeNeeds);
        }
    }
    public void calcLoyalty()
    {
        // if (loyalty.get() > 0)
        if (NeedsFullfilled.get() >= 1f)
        {
            loyalty.add(new Value(0.01f));
            if (loyalty.get() > 1f) loyalty.set(1f);
            else;
        }
        else
            if (NeedsFullfilled.get() >= 0.50f)
            loyalty.subtract(new Value(0.01f));
        else
            loyalty.subtract(new Value(0.02f));
    }

    public override void simulate()
    {

    }

    public void PayToAllAristocrats()
    {
        if (this.ShouldPayAristocratTax())
        {
            Value taxSize = new Value(0);
            taxSize = produced.value.multiple(owner.aristocrstTax);
            province.PayToAllAristocrats(storage.value, taxSize);
            //storage.value.pay(country.storage.value, taxSize);
        }
    }

    private bool ShouldPayAristocratTax()
    {
        if (this.type == PopType.tribeMen || this.type == PopType.farmers)
            return true;
        else return false;

    }

    public static void SetZeroIncome()
    {
        List<PopUnit> allArisocrats;
        foreach (Province pr in Province.allProvinces)
        {
            allArisocrats = pr.FindAllPopUnits(PopType.aristocrats);
            foreach (PopUnit pop in allArisocrats)
                pop.produced.set(0);
        }
    }

    public void calcPromotions()
    {

    }

    //private bool CanDemote()
    //{
    //    if (popType == PopType.aristocrats)
    //        return true;
    //    else
    //        if (popType == PopType.tribeMen && countryOwner.farming.Invented())
    //        return true;
    //    return false;
    //}
    //public void Growth(uint size)
    //{

    //}
    public void calcGrowth()
    {
        //uint growthSize = getGrowthSize();
        population =(uint)( population + getGrowthSize());
    }
    public void calcDemotions()
    {
        uint demotionSize = getDemotionSize();
        //&& CanDemote()
        if (WantsDemotion() && demotionSize > 0 && this.population > demotionSize)
            Demote(getRichestDemotionTarget(), demotionSize);
    }
    public List<PopType> getDemotionList()
    {
        List<PopType> result = new List<PopType>();
        foreach (PopType type in PopType.allPopTypes)
            if (CanThisDemoteInto(this.type))
                result.Add(type);
        return result;
    }
    //TODO rewrite
    public PopType getRichestDemotionTarget()
    {

        if (this.type == PopType.tribeMen)
        {
            //demoting to aristocrats...
            Value aristoLevel = this.province.getMiddleNeedFullfilling(PopType.aristocrats);
            //demoting to farmers...
            Value farmersLevel = new Value(0);
            if (this.owner.farming.Invented())
            {
                farmersLevel = this.province.getMiddleNeedFullfilling(PopType.farmers);
                if (aristoLevel.get() > farmersLevel.get())
                    return PopType.aristocrats;
                else
                    return PopType.farmers;
            }
            else
                return PopType.aristocrats;


        }
        else
        if (this.type == PopType.aristocrats)
        {
            //demoting to tribeMen...
            Value trbeMenLevel = this.province.getMiddleNeedFullfilling(PopType.tribeMen);
            //demoting to farmers...
            Value farmersLevel;
            if (this.owner.farming.Invented())
            {
                farmersLevel = this.province.getMiddleNeedFullfilling(PopType.farmers);
                if (trbeMenLevel.get() > farmersLevel.get())
                    return PopType.tribeMen;
                else
                    return PopType.farmers;
            }
            else
                return PopType.tribeMen;
        }
        else
        if (this.type == PopType.farmers)
        {
            //demoting to tribeMen...
            Value trbeMenLevel = this.province.getMiddleNeedFullfilling(PopType.tribeMen);
            //demoting to arisocrats...
            Value aristoLevel;
            aristoLevel = this.province.getMiddleNeedFullfilling(PopType.aristocrats);
            if (trbeMenLevel.get() > aristoLevel.get())
                return PopType.tribeMen;
            else
                return PopType.aristocrats;

        }
        else return null;

    }
    public bool CanThisDemoteInto(PopType popType)
    {
        if (popType == PopType.aristocrats)
            return true;
        else
             if (popType == PopType.tribeMen && owner.farming.Invented())
            return true;
        return false;
    }
    private void Demote(PopType type, uint amount)
    {
        PopUnit newPop = new PopUnit(this);
        newPop.population = amount;
        newPop.type = type;
        this.population -= amount;
    }

    public uint getDemotionSize()
    {
        return (uint)Mathf.RoundToInt(this.population * PopUnit.demotionSpeed.get());
    }
    public int getGrowthSize()
    {
        int result = 0;
        if (this.NeedsFullfilled.get() > 0.20f) // positive grotwh
            result = Mathf.RoundToInt(PopUnit.growthSpeed.get() * population);
        else
            if (this.NeedsFullfilled.get() >= 0.10f) // zero grotwh
            result = 0;
        else  //starvation
        {
            result = Mathf.RoundToInt(PopUnit.starvationSpeed.get() * population * -1);
            if (result * -1 >= population) // total starvation
                result = 0;
        }

        return result;
        //return (uint)Mathf.RoundToInt(this.population * PopUnit.growthSpeed.get());
    }
    public bool WantsDemotion()
    {
        float demotionLimit = 0.33f;
        if (this.NeedsFullfilled.get() < demotionLimit)
            return true;
        else return false;
    }

    internal void Merge(PopUnit pop)
    {
        population = population + pop.population;
        //storage.value.add(pop.storage.value);
        //produced = new Storage(Product.findByName("Venison"), 0);
        //education = new Procent(0.01f);
        //loyalty = new Procent(0.50f);
        //NeedsFullfilled = new Procent(1f);        
        //TODO finish
    }
}