﻿using UnityEngine;
using System.Collections;
//using System;

public class Procent : Value {
    //uint value;
    public static bool GetChance(uint procent)
    {
        //TODO fix that shit
        float realLuck = Random.value* 100; // (0..100 including)
        if (procent >= realLuck)
        return true;
        else
            return false;
    }
    //uint get() { return value.g; }
    public  Procent(float number) : base(number)
    {
        
    }
    public override string ToString()
    {
        if (get() > 0)
            return System.Convert.ToString(get() * 100f) + "%";
        else return "0%";
    }

    
}
