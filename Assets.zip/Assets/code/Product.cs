﻿using System.Collections.Generic;



public class Product
{
    //private static HashSet<Product> allProducts = new HashSet<Product>();
    static List<Product> allProducts = new List<Product>();


    bool storable = true;
    private string name;

    public Product(string inName)
    {
        name = inName;
        allProducts.Add(this);
        //allProducts.Add(new Product("shiit"));
        //TODO checks for duplicates&
    }

    //static void AddProduct(Product product)
    //{
    //    allProducts.Add(product);

    //}

    public static Product findByName(string name)
    {
        //HashSet set = new HashSet();
        foreach (Product next in allProducts)
        {
            //if (next.getName().equalsIgnoreCase(name))
            if (next.getName().Equals(name))
            {
                return next;
            }
        }
        return null;

    }
    public string getName()
    {
        return name;
    }
    bool isStorable()
    {
        return storable;
    }
    void setStorable(bool isStorable)
    {
        this.storable = isStorable;
    }
    public string tostring()
    {
        return getName();

    }
}
