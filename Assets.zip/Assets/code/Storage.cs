﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class StorageSet
{
    private List<Storage> container = new List<Storage>();
}
public class Storage
{
    private Product product;
    public Value value;
    //public Storage(JSONObject jsonObject)
    //{
    //    // TODO Auto-generated constructor stub
    //}
    public Storage(Product inProduct, float inAmount)
    {
        product = inProduct;
        value = new Value (inAmount);
        // TODO exceptions!!
    }

    public Storage(Product product)
    {
        this.product = product;
        value = new Value(0);
    }

    public void set(Product inProduct, float inAmount)
    {
        product = inProduct;
        //value = new Value(inAmount);
        value.set(inAmount);
    }
    public void set( Value inAmount)
    {        
        value = inAmount;
    }
    public void set(float inAmount)
    {
        value.set(inAmount);
        //value = new Value(inAmount);
    }
    public Product getProduct()
    {
        return product;
    }
    //public float getValue()
    //{
    //    return value.get();
    //}
    //public void add(float amount)
    //{
    //    this.value += amount;
    //}
    //void setValue(float value)
    //{
    //    this.value = value; ;
    //}
    override public string ToString()
    {
        return value.get() + " " + getProduct().getName();

    }
    /*public String toString(){
		return getProduct().getName();
		
	}*/
}
