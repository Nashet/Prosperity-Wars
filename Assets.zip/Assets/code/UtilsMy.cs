﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using System;

public class Value
{
    ///<summary> storing as value as number * precision </summary>
    private uint value;
    static uint precision = 100; // 0.01
    public Value(float number)
    {
        set(number); // set allready have multiplier
    }
    //TODO overflow checks?
    public void add(Value invalue)
    {
        value += invalue.value;
    }
    public void add(uint invalue)
    {
        value += invalue * precision;
    }
    public void add(float invalue)
    {
        value += (uint)Mathf.RoundToInt(invalue * precision);
    }
    public void subtract(Value invalue)
    {
        if (invalue.value > value)
        {
            //Debug.Log("Value subtrack failed");
            set(0);
        }
        else
            value -= invalue.value;
    }
    public void subtract(float invalue)
    {
        if (invalue > value)
            Debug.Log("Value subtrack failed");
        value -= (uint)Mathf.RoundToInt(invalue * precision);
    }
    //public void multiple(Value invalue)
    //{
    //    if (invalue.get() < 0 )
    //        Debug.Log("Value multiple failed");
    //    value = (uint)(value * invalue.get());
    //}

        /// <summary>
        /// returns new value
        /// </summary>
        /// <param name="invalue"></param>
        /// <returns>new Value</returns>
    public Value multiple(Value invalue)
    {
        if (invalue.get() < 0)
            Debug.Log("Value multiple failed");
        return new Value(get() * invalue.get());
    }
    /// <summary>
    /// returns new value
    /// </summary>
    internal Value multiple(uint invalue)
    {
        //if (invalue.get() < 0)
          //  Debug.Log("Value multiple failed");
        return new Value(get() * invalue);
    }

    

    /// <summary>returns new value </summary>
    internal Value divide(uint invalue)
    {
        if (invalue == 0) Debug.Log("Value ivide by zero");

        return new Value(get() / invalue);
    }
    public void pay(Value another, uint amount)
    {
        if (this.get() >=  amount)
        {
            this.subtract(amount);
            another.add(amount);
        }
        else Debug.Log("value payment failed");
    }
    public void pay(Value another, float amount)
    {
        if (this.get() >=  amount)
        {
            this.subtract(amount);
            another.add(amount);
        }
        else Debug.Log("value payment failed");
    }
    public void pay(Value another, Value amount)
    {
        if (this.get() >=  amount.get())
        {
            this.subtract(amount);
            another.add(amount);
        }
        else Debug.Log("value payment failed");
    }
    public void sendAll(Value another)
    {
        another.add(this);
        this.set(0);
    }
    // toDO tatally screwed file
    public float get()
    {
        return (float)value / (float)precision; //TODO roundation fakup
    }
    public void set(float invalue)
    {
        value = (uint)Mathf.RoundToInt(invalue * precision);
        
    }
    override public string ToString()
    {
        if (value >0)
        return System.Convert.ToString(get());
        else return "0";
    }

    
}
public static class UtilsMy
{
    public static bool isSameColorsWithoutAlpha(Color colorA, Color colorB)
    {
        if (colorA.b == colorB.b && colorA.g == colorB.g && colorA.r == colorB.r)
            return true;
        else
            return false;

    }
    public static float getHumidityRatio(float massVapor, float massDryAir)
    {
        return massVapor / massDryAir;
    }
    public static GameObject CreateButton(Transform parent, float x, float y,
                                        float w, float h, string message,
                                        UnityAction eventListner)
    {
        GameObject buttonObject = new GameObject("Button");
        buttonObject.transform.SetParent(parent);

        //buttonObject.layer = LayerUI;

        RectTransform trans = buttonObject.AddComponent<RectTransform>();
        SetSize(trans, new Vector2(w, h));
        trans.anchoredPosition3D = new Vector3(0, 0, 0);
        trans.anchoredPosition = new Vector2(x, y);
        trans.localScale = new Vector3(1.0f, 1.0f, 1.0f);
        trans.localPosition.Set(0, 0, 0);

        CanvasRenderer renderer = buttonObject.AddComponent<CanvasRenderer>();

        Image image = buttonObject.AddComponent<Image>();

        Texture2D tex = Resources.Load<Texture2D>("button_bkg");
        image.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height),
                                                  new Vector2(0.5f, 0.5f));

        Button button = buttonObject.AddComponent<Button>();
        button.interactable = true;
        button.onClick.AddListener(eventListner);

        GameObject textObject = CreateText(buttonObject.transform, 0, 0, 0, 0,
                                                   message, 24);

        return buttonObject;
    }
    private static void SetSize(RectTransform trans, Vector2 size)
    {
        Vector2 currSize = trans.rect.size;
        Vector2 sizeDiff = size - currSize;
        trans.offsetMin = trans.offsetMin -
                                  new Vector2(sizeDiff.x * trans.pivot.x,
                                      sizeDiff.y * trans.pivot.y);
        trans.offsetMax = trans.offsetMax +
                                  new Vector2(sizeDiff.x * (1.0f - trans.pivot.x),
                                      sizeDiff.y * (1.0f - trans.pivot.y));
    }
    private static GameObject CreateText(Transform parent, float x, float y,
                                     float w, float h, string message, int fontSize)
    {
        GameObject textObject = new GameObject("Text");
        textObject.transform.SetParent(parent);

        //textObject.layer = LayerUI;

        RectTransform trans = textObject.AddComponent<RectTransform>();
        trans.sizeDelta.Set(w, h);
        trans.anchoredPosition3D = new Vector3(0, 0, 0);
        trans.anchoredPosition = new Vector2(x, y);
        trans.localScale = new Vector3(1.0f, 1.0f, 1.0f);
        trans.localPosition.Set(0, 0, 0);

        CanvasRenderer renderer = textObject.AddComponent<CanvasRenderer>();

        Text text = textObject.AddComponent<Text>();
        text.supportRichText = true;
        text.text = message;
        text.fontSize = fontSize;
        text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
        text.alignment = TextAnchor.MiddleCenter;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.color = new Color(0, 0, 1);

        return textObject;
    }

    public static Texture2D FlipTexture(Texture2D original)
    {
        Texture2D flipped = new Texture2D(original.width, original.height);

        int xN = original.width;
        int yN = original.height;


        for (int i = 0; i < xN; i++)
        {
            for (int j = 0; j < yN; j++)
            {
                flipped.SetPixel(xN - i - 1, j, original.GetPixel(i, j));
            }
        }
        flipped.Apply();

        return flipped;
    }
}
